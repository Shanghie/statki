#ifndef CELL_STATE_H
#define CELL_STATE_H

enum CellState { EMPTY, SHIP, HIT, MISS };

#endif // CELL_STATE_H
