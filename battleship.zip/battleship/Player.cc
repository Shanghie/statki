#include "Player.h"

void Player::placeShips() {
    vector<Ship> ships = {
        {"Jednomasztowiec", 1}, {"Jednomasztowiec", 1}, {"Jednomasztowiec", 1}, {"Jednomasztowiec", 1},
        {"Dwumasztowiec", 2}, {"Dwumasztowiec", 2}, {"Dwumasztowiec", 2},
        {"Trzymasztowiec", 3}, {"Trzymasztowiec", 3},
        {"Czteromasztowiec", 4}
    };

    for (const auto& ship : ships) {
        int x, y;
        char orientation;
        bool placed = false;

        while (!placed) {
            cout << "Umieść statek " << ship.name << " (rozmiar " << ship.size << ").\n";
            cout << "Podaj współrzędne (x y) i orientację (h - poziomo, v - pionowo): ";

            string input;
            getline(cin, input);
            stringstream ss(input);

            if (ss >> x >> y >> orientation && (orientation == 'h' || orientation == 'v')) {
                bool horizontal = (orientation == 'h');
                placed = board.placeShip(x, y, ship, horizontal);

                if (!placed) {
                    cout << "Nie można ustawić statku w tej pozycji. Spróbuj ponownie.\n";
                } else {
                    cout << "Aktualna plansza po umieszczeniu statku:\n";
                    board.display(true);
                }
            } else {
                cout << "Niepoprawne dane wejściowe. Spróbuj ponownie.\n";
            }
        }
    }
}

void Player::displayBoard(bool showShips) const {
    board.display(showShips);
}

bool Player::attack(Player &opponent, int x, int y) {
    return opponent.board.shoot(x, y);
}

bool Player::hasLost() const {
    return board.allShipsSunk();
}
